package com.example.golfapplication;

public class spinner {
}
